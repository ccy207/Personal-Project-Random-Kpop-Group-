<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "randomgroup";
$year = trim($_POST["RandomYear"] ?? "");
$groups = [];

if (!preg_match('/^\d{4}$/', $year)) {
    echo "Please enter a valid four-digit year.";
} else {
    $connection = mysqli_connect($hostname, $username, $password, $database);
    if (!$connection) {
        die("Database connection failed: " . mysqli_connect_error());
    }else{
       
    }

    $query = "SELECT Name, Short, Gender, Debut, Company, Members, OrigMemb, FanclubName, Active
              FROM kpopgroup
              WHERE CAST(SUBSTRING_INDEX(Debut, '/', -1) AS UNSIGNED) = ?
              ORDER BY Name ASC";
    $statement = mysqli_prepare($connection, $query);
    if (!$statement) {
        die("Query preparation failed: " . mysqli_error($connection));
    }

    $yearValue = (int) $year;
    mysqli_stmt_bind_param($statement, "i", $yearValue);
    if (!mysqli_stmt_execute($statement)) {
        die("Query failed: " . mysqli_stmt_error($statement));
    }

    $result = mysqli_stmt_get_result($statement);
    while ($row = mysqli_fetch_assoc($result)) {
        $groups[] = $row;
    }

    mysqli_stmt_close($statement);
    mysqli_close($connection);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            background-color: #cdcdcd;
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
        }
        </style>
</head>
<body>
    <?php if (count($groups) === 0): ?>
            <p>No groups found debuting in <?= htmlspecialchars($year) ?>.</p>
        <?php else: ?>
            <table border="1" cellpadding="5" cellspacing="3">
                <tr>
                    <th>Name</th>
                    <th>Short</th>
                    <th>Gender</th>
                    <th>Debut Date</th>
                    <th>Company</th>
                    <th>Members</th>
                    <th>Orig Memb</th>
                    <th>Fanclub Name</th>
                    <th>Active</th>
                </tr>
                <?php foreach ($groups as $group): ?>
                    <tr>
                        <?php foreach ($group as $value): ?>
                            <td><?= (string) $value ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
            <p>Found <?= count($groups) ?> group(s).</p>
        <?php endif; ?>
        <p><a href="RandomGroup.html">Search another year</a></p>
</body>
</html>

        

